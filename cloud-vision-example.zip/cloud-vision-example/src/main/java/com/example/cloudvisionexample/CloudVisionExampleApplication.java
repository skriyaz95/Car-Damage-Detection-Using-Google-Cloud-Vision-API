package com.example.cloudvisionexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudVisionExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(CloudVisionExampleApplication.class, args);
    }

}

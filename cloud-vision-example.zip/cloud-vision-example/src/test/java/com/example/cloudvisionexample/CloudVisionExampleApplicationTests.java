package com.example.cloudvisionexample;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudVisionExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
